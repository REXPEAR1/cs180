/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author MiNG
 */
public class Undergrad extends Student{
    private String major;

    public String getMajor() {
        return major;
    }

    public void setMajor(String Major) {
        this.major = Major;
    }
    
    
}
